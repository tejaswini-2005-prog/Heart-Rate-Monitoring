#include <OneWire.h>
#include <DallasTemperature.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>
#include <Adafruit_MQTT.h>
#include <Adafruit_MQTT_Client.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#define TEMP_SENSOR 14
#define MOTION_DETECTOR 12

#define BUZZER_PIN_1 4   
#define BUZZER_PIN_2 16    
#define BUZZER_PIN_3 17
#define BUZZER_PIN_4 5

#define SW_TEMP 32
#define SW_HR 33
#define SW_SPO2 25
#define SW_MOTION 26

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET   -1
#define OLED_ADDRESS 0x3C

#define WIFI_SSID "Wokwi-GUEST"
#define WIFI_PASS ""


#define IO_USERNAME  "tejaswini_27"
#define IO_KEY       "aio_kDLX30RhsTtcTs2zm1iNeuUUoBsY"

#define AIO_SERVER      "io.adafruit.com"
#define AIO_SERVERPORT  1883

#define TEMP_FEED         IO_USERNAME "/feeds/body-temperature-degrees-c"
#define HR_FEED           IO_USERNAME "/feeds/heart-rate-monitor"
#define MOTION_FEED       IO_USERNAME "/feeds/motion-detector"
#define SPO2_FEED         IO_USERNAME "/feeds/spo2-percent"
#define FLAG              IO_USERNAME "/feeds/flag"

WiFiClient client;

Adafruit_MQTT_Client mqtt(&client, AIO_SERVER, AIO_SERVERPORT,
                          IO_USERNAME, IO_KEY);

Adafruit_MQTT_Publish tempFeed   = Adafruit_MQTT_Publish(&mqtt, TEMP_FEED);
Adafruit_MQTT_Publish hrFeed     = Adafruit_MQTT_Publish(&mqtt, HR_FEED);
Adafruit_MQTT_Publish spo2Feed   = Adafruit_MQTT_Publish(&mqtt, SPO2_FEED);
Adafruit_MQTT_Publish statusFeed = Adafruit_MQTT_Publish(&mqtt, FLAG);
Adafruit_MQTT_Publish motiondetectorFeed = Adafruit_MQTT_Publish(&mqtt, MOTION_FEED);

OneWire oneWire(TEMP_SENSOR);
DallasTemperature sensors(&oneWire);

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

QueueHandle_t hrQueue;
QueueHandle_t spo2Queue;

void sensorTask(void *param) {

  int heartRate;
  int spo2;

  while (1) {
 
  if(!digitalRead(SW_HR)){
    heartRate = random(45, 300);
  }
  else heartRate = 0;

  if(!digitalRead(SW_SPO2)){
    spo2      = random(60, 100);
  }
  else spo2 = 0;

    xQueueOverwrite(hrQueue, &heartRate);
    xQueueOverwrite(spo2Queue, &spo2);

    vTaskDelay(pdMS_TO_TICKS(5000));
  }
}



void processingTask(void *param) {

  float temperature;
  int heartRate;
  int spo2;

  const char *statusMsg;

  while (1) {

    xQueuePeek(hrQueue, &heartRate, 0);
    xQueuePeek(spo2Queue, &spo2, 0);

   if(!digitalRead(SW_TEMP)){
    sensors.requestTemperatures();
    temperature = sensors.getTempCByIndex(0);
   }

    statusMsg = "OK";

    if (temperature > 38.0) {
      statusMsg = "High body temperature";
    }
    else if (heartRate < 60) {
      statusMsg = "Heart rate below normal";
    }
    else if (heartRate > 300) {
      statusMsg = "Heart rate above normal";
    }
    else if (spo2 < 85) {
      statusMsg = "SpO2 below normal";
    }
    else if (digitalRead(MOTION_DETECTOR) && !digitalRead(SW_MOTION)) {
      statusMsg = "Motion Detected!";
    }





    display.clearDisplay();

    display.setCursor(0, 0);
    display.print("Temp: ");
    display.print(temperature);
    display.print(" C");

    display.setCursor(0, 16);
    display.print("HR: ");
    display.print(heartRate);

    display.setCursor(0, 32);
    display.print("SpO2: ");
    display.print(spo2);
    display.print(" %");

    display.setCursor(0, 48);
    display.print(statusMsg);

    display.display();

if(temperature > 38){
    digitalWrite(BUZZER_PIN_1, HIGH);
    vTaskDelay(pdMS_TO_TICKS(50));
    digitalWrite(BUZZER_PIN_1, LOW);
    vTaskDelay(pdMS_TO_TICKS(50));
}

if((heartRate < 60 || heartRate > 300)){
    digitalWrite(BUZZER_PIN_2, HIGH);
    vTaskDelay(pdMS_TO_TICKS(50));
    digitalWrite(BUZZER_PIN_2, LOW);
    vTaskDelay(pdMS_TO_TICKS(50));
}

if(spo2 < 85){
    digitalWrite(BUZZER_PIN_3, HIGH);
    vTaskDelay(pdMS_TO_TICKS(50));
    digitalWrite(BUZZER_PIN_3, LOW);
    vTaskDelay(pdMS_TO_TICKS(50));
}

if(digitalRead(MOTION_DETECTOR)){
    digitalWrite(BUZZER_PIN_4, HIGH);
    vTaskDelay(pdMS_TO_TICKS(50));
    digitalWrite(BUZZER_PIN_4, LOW);
    vTaskDelay(pdMS_TO_TICKS(50));
}


    if (!mqtt.connected()) {
      while (mqtt.connect() != 0) {
        vTaskDelay(pdMS_TO_TICKS(500));
      }
    }

    mqtt.processPackets(10);
    mqtt.ping();

    tempFeed.publish(temperature);
    hrFeed.publish((int32_t)heartRate);
    spo2Feed.publish((int32_t)spo2);
    motiondetectorFeed.publish((int32_t)digitalRead(MOTION_DETECTOR));
    statusFeed.publish(statusMsg);

    vTaskDelay(pdMS_TO_TICKS(5000));
  }
}


void setup() {

  Serial.begin(115200);

  pinMode(BUZZER_PIN_1, OUTPUT);
  pinMode(BUZZER_PIN_2, OUTPUT);
  pinMode(BUZZER_PIN_3, OUTPUT);
  pinMode(BUZZER_PIN_4, OUTPUT);

  pinMode(MOTION_DETECTOR, INPUT);

  pinMode(SW_TEMP, INPUT);
  pinMode(SW_HR, INPUT);
  pinMode(SW_SPO2, INPUT);
  pinMode(SW_MOTION, INPUT);


  sensors.begin();
  Wire.begin(21, 22);

  display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS);
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.clearDisplay();

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }

  hrQueue   = xQueueCreate(1, sizeof(int));
  spo2Queue = xQueueCreate(1, sizeof(int));

  xTaskCreatePinnedToCore(sensorTask, "SensorTask", 4096, NULL, 1, NULL, 1);

  xTaskCreatePinnedToCore(processingTask, "ProcessTask", 6144, NULL, 2, NULL, 0);

}

void loop() {
  vTaskDelay(portMAX_DELAY);
}